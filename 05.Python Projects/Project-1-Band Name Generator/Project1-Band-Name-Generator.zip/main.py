print("Welcome to the Band Name Generator.")
city = input("Which city did you grew up in?\n")
pet = input("What is the name of a pet?\n")
print("Your band name could be: " + city + " " + pet)
